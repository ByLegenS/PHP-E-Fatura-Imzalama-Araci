package ntg.bls;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.Context;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignature;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignatureException;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.config.Config;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.net.URL;

/**
 * Represents a base for signature samples
 * @author suleyman.uslu
 */
public class SampleBase
{
    protected static String ROOT_DIR;           // root directory of project
    protected static String CONFIG;             // config file path
    protected static String BASE_DIR;           // base directory where signatures created
    protected static String POLICY_FILE;        // certificate validation policy file path
    protected static String POLICY_FILE_CRL;    // path of policy file without OCSP
    protected static String PIN;                // smart card PIN

    protected static boolean IS_QUALIFIED;      // true if qualified certificates to be used

    static {

        URL root = SampleBase.class.getResource("/");
        String classPath = root.getPath();
        File binDir = new File(classPath);
        ROOT_DIR = binDir.getParentFile().getAbsolutePath()+"/";


        BASE_DIR = ROOT_DIR + "/";
        CONFIG = ROOT_DIR + "/config/xmlsignature-config.xml";
        POLICY_FILE = ROOT_DIR + "/config/certval-policy-test.xml";
        POLICY_FILE_CRL = ROOT_DIR + "/config/certval-policy-test-crl.xml";

        IS_QUALIFIED = false;

    }

    /**
     * Creates context for signature creation and validation
     * @return created context
     */
    public static Context createContext() {
    	
    	Context context = null;
    	try {
			context = new Context(BASE_DIR);
			context.setConfig(new Config(CONFIG));
	        
		} catch (XMLSignatureException e) {
			e.printStackTrace();
		}
    	return context;
    }


    /**
     * Reads an XML document into DOM document format
     * @param uri XML file to be read
     * @param aContext signature context
     * @return DOM document format of read XML document
     * @throws Exception
     */
    public static Document parseDoc(String uri, Context aContext) throws Exception {

        // generate document builders for parsing
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder db = dbf.newDocumentBuilder();

        // open the document
        File f = new File(BASE_DIR + uri);

        // parse into DOM format
        Document document = db.parse(f);
        aContext.setDocument(document);

        return document;
    }

    /**
     * Gets the signature by searching for tag in an enveloped signature
     * @param aDocument XML document to be looked for
     * @param aContext signature context
     * @return XML signature in the XML document
     * @throws Exception
     */
    public XMLSignature readSignature(org.w3c.dom.Document aDocument, Context aContext) throws Exception {

        // get the signature in enveloped signature format
        Element signatureElement = ((Element)aDocument.getDocumentElement().getElementsByTagName("ds:Signature").item(0));

        // return the XML signature created with signature element
        return new XMLSignature(signatureElement, aContext);
    }

    /**
     * Gets the signature by searching for tag in a parallel signature
     * @param aDocument XML document to be looked for
     * @param aContext signature context
     * @param item order of signature to be read in parallel structure
     * @return XML signature in the XML document
     * @throws Exception
     */
    public XMLSignature readSignature(org.w3c.dom.Document aDocument, Context aContext, int item) throws Exception {

        // get the first signature element searching for the tag in the XML document
        Element signatureElement = ((Element)((Element)aDocument.getDocumentElement().getElementsByTagName("signatures").item(0)).getElementsByTagName("ds:Signature").item(item));

        // return the XML signature using signature element
        return new XMLSignature(signatureElement, aContext);
    }
}
